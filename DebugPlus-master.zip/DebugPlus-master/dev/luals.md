# LuaLS

Theres a config for [luaLS](https://luals.github.io/) in here by default. To get the best results do something like:

```sh
mkdir .lib
cd .lib

ln -s ~/path/to/smods smods
ln -s ~/path/to/game/files balatro
git clone https://github.com/LuaCATS/love2d
```

