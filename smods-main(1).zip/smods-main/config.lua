return {
    ["no_mod_badges"] = false,
    ["graphics_mipmap_level"] = 3,
    ["graphics_mipmap_level_options"] = {0, 2, 4, 8},
    ["achievements"] = 1,
    ["seeded_unlocks"] = false,
}